﻿/*amespace JWTCodeFirst.Auth
{
    public class UserRole
    {
    }
}*/

namespace ProjectAPI.Auth
{
    public class UserRoles
    {
        public const string Admin = "admin";
        public const string User = "admin";
    }
}