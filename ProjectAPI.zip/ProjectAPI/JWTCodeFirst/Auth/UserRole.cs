﻿/*amespace JWTCodeFirst.Auth
{
    public class UserRole
    {
    }
}*/


namespace JWTCodeFirst.Auth
{
    public class UserRoles
    {
        public const string Admin = "admin";
        public const string User = "admin";
    }
}