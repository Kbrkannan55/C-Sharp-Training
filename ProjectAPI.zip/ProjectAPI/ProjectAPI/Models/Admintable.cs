﻿using System;
using System.Collections.Generic;

namespace ProjectAPI.Models;

public partial class Admintable
{
    public int Id { get; set; }

    public string? AdminPassword { get; set; }
}
