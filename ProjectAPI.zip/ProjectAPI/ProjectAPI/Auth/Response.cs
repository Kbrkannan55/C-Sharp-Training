﻿/*namespace JWTCodeFirst.Auth
{
    public class Response
    {
    }
}
*/

namespace ProjectAPI.Auth
{
    public class Response
    {
        public string Status { get; set; }
        public string Error { get; set; }
    }
}