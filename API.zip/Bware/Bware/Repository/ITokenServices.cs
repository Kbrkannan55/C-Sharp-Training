﻿using Bware.Auth;
using System.Security.Claims;
namespace Gym_Management.Repository.Token
{
    public interface ITokenService
    {
        TokenResponse GetToken(IEnumerable<Claim> claim);
        string GetRefreshToken();
        ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    }
}